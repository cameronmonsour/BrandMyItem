"""
BrandMyItem precision surface scanner (v2).
Run once per catalog asset. Anchored to real manufacturer measurements.

Per item it outputs:
  surface      [x,y,w,h] in image pixels  — the ad surface, locked
  ppi          pixels per inch, calibrated from the item's real spec dimension
  surface_in   the surface in real inches — used for print files and listings
  qa           mode used + aspect error vs. the physical spec (angle/crop check)

Usage:  python3 scan_surfaces.py           (uses SPECS below over assets/)
Deps:   pip install pillow scipy numpy
"""
import numpy as np, json
from PIL import Image
from scipy import ndimage

def largest_rect(mask):
    h, w = mask.shape
    heights = np.zeros(w, dtype=int); best=(0,0,0,0); best_area=0
    for y in range(h):
        heights = np.where(mask[y], heights+1, 0)
        stack=[]
        for x in range(w+1):
            cur = heights[x] if x < w else 0
            start = x
            while stack and stack[-1][1] > cur:
                sx, sh = stack.pop()
                if sh*(x-sx) > best_area: best_area = sh*(x-sx); best=(sx, y-sh+1, x-sx, sh)
                start = sx
            stack.append((start,cur))
    return best

def scan(path, spec, alpha_thresh=8, margin_in=0.30, texture_q=0.88, keep_frac=0.30, max_strip=3.0):
    """1. item mask from soft alpha + hole fill.
       2. calibrate px/inch on the item's known real dimension.
       3. interior = distance transform >= a real-inch margin (0.30\" off every edge).
       4. texture-carve to dodge hardware (latches, cameras); adaptively rejected
          when the whole face is textured (ribs, grain) or the result is a strip.
       5. largest inscribed rectangle = the surface. Deterministic, integers, locked."""
    im = Image.open(path).convert("RGBA"); W,H = im.size
    a = np.array(im)[:,:,3] >= alpha_thresh
    mask0 = ndimage.binary_fill_holes(a)
    ys, xs = np.where(mask0)
    bw, bh = xs.max()-xs.min()+1, ys.max()-ys.min()+1
    ppi = (bw/spec["in"][0]) if spec["axis"]=="w" else (bh/spec["in"][1])
    aspect_err = abs((bw/bh) - (spec["in"][0]/spec["in"][1])) / (spec["in"][0]/spec["in"][1])
    interior = ndimage.distance_transform_edt(mask0) >= max(2, int(round(margin_in*ppi)))
    base = largest_rect(interior)
    g = np.array(im.convert("L"), dtype=float)
    gx = np.abs(np.diff(g, axis=1, prepend=g[:, :1])); gy = np.abs(np.diff(g, axis=0, prepend=g[:1, :]))
    grad = ndimage.gaussian_filter(gx+gy, 2)
    carved = largest_rect(interior & (grad <= np.quantile(grad[mask0], texture_q)))
    ar = max(carved[2],1)/max(carved[3],1)
    ok = carved[2]*carved[3] >= keep_frac*base[2]*base[3] and (1/max_strip) <= ar <= max_strip
    (x,y,w,h), mode = (carved, "texture-carved") if ok else (base, "full-face")
    return {"img": path.split("/")[-1], "size":[W,H], "surface":[int(x),int(y),int(w),int(h)],
            "ppi": round(ppi,2), "surface_in":[round(w/ppi,2), round(h/ppi,2)],
            "item_in": spec["in"], "spec_src": spec["src"],
            "qa": {"mode": mode, "aspect_err_pct": round(aspect_err*100,1)}}

# ---- ground truth: one real dimension pair per catalog asset ----
# axis: which photo axis calibrates ("w" or "h"). Replace (est.) entries with
# the exact manufacturer spec for the SKU you actually stock.
SPECS = {
 "macbook":    {"in":[12.31, 8.71],  "axis":"w", "src":"Apple: MacBook Pro 14 = 12.31 x 8.71 in"},
 "headphones": {"in":[6.64, 7.37],   "axis":"h", "src":"Apple: AirPods Max 6.64 W x 7.37 H in"},
 "suitcase":   {"in":[15.8, 21.7],   "axis":"h", "src":"cabin class ~15.8 x 21.7 in (est.)"},
 "cooler":     {"in":[25.75, 16.1],  "axis":"w", "src":"Tundra 45 class 25.75 x 16.1 in (est.)"},
 "duffel":     {"in":[21.0, 13.0],   "axis":"w", "src":"weekender class ~21 x 13 in (est.)"},
 "backpack":   {"in":[12.5, 18.5],   "axis":"h", "src":"commuter class ~12.5 x 18.5 in (est.)"},
 "phone":      {"in":[2.82, 5.81],   "axis":"h", "src":"iPhone class 2.82 x 5.81 in (est.)"},
 "bag":        {"in":[13.0, 36.0],   "axis":"h", "src":"cart bag class ~13 x 36 in (est.)"},
 "tumbler":    {"in":[5.2, 12.3],    "axis":"h", "src":"40oz class ~12.3 in tall (est.)"},
}

if __name__ == "__main__":
    out = {}
    for k, spec in SPECS.items():
        out[k] = scan(f"assets/{k}.png", spec)
        d = out[k]
        print(f"{k:11s} {d['qa']['mode']:14s} px{d['surface']}  =  {d['surface_in'][0]}in x {d['surface_in'][1]}in   aspect_err {d['qa']['aspect_err_pct']}%")
    json.dump(out, open("catalog_surfaces.json","w"), indent=1)
