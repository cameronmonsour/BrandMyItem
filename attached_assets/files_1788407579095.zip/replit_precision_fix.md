# Replit prompt — make ad-spot placement pixel-locked (airline-controller precision)

The current spot boxes fade, drift, and follow irregular contours. Replace the entire spot-rendering approach with the system below. Three files are attached: `scan_surfaces.py` (the precision scanner), `catalog_surfaces.json` (the locked surface data), and the working reference demo `bmi_spot_splitter.html`.

## Why the current boxes are wrong (do not keep any of this)
1. **Boxes are positioned as separate divs with % CSS over the image.** Rounding at each breakpoint drifts them. Any mismatch between the image's rendered box and the overlay's box (object-fit, padding, max-width) misplaces every spot.
2. **Dotted/dashed, low-opacity strokes.** They read as "faded." Our design law is solid lines only, full opacity.
3. **Contour-following shapes.** Tracing the silhouette per-render produces the wobbly outlines in the screenshots. Surfaces are rectangles, computed once, stored as data, never re-derived at render time.

## The system
### 1. Surfaces are data, not detection
`catalog_surfaces.json` contains, per product image:
- `size` — the image's intrinsic pixel size
- `surface` — [x, y, w, h] of the ad surface **in that image's own pixel space**
- `ppi` — pixels per inch, calibrated from the item's real manufacturer dimension (e.g. MacBook Pro 14" = 12.31 × 8.71 in from Apple; AirPods Max = 6.64 × 7.37 in from Apple)
- `surface_in` — the surface in real inches (use this on listings and for print/production files)
- `qa` — scan mode + aspect error vs. the physical spec (a big error means the photo is angled or cropped: reshoot, don't ship)

Never compute placement in the browser. Load the JSON, draw the rectangles.

### 2. When a new product photo is added
Run once: `python3 scan_surfaces.py`. It reads the transparent cutout, calibrates pixels-to-inches from the SPECS table (add the real manufacturer dimension for each new SKU — that's the ground truth), keeps the surface 0.30 real inches off every silhouette edge, dodges hardware (latches, cameras) with texture analysis, and writes the locked rectangle. Eyeball the printed QA line; hand-edit the JSON if you ever disagree. Then it's locked forever.

### 3. The one correct way to render (drop-in)
One `<svg>` per product image. Same intrinsic coordinate space. Absolutely positioned to cover the image exactly. Nothing else.

```html
<div class="spot-stage" style="position:relative; width:fit-content">
  <img src="ITEM.png" style="display:block; width:100%; height:auto">
  <svg viewBox="0 0 {size[0]} {size[1]}"
       style="position:absolute; inset:0; width:100%; height:100%"
       preserveAspectRatio="none">
    <!-- one rect per spot cell, from splitGrid() below -->
    <rect x="…" y="…" width="…" height="…" rx="8"
          fill="none" stroke="{ink}" stroke-width="2"
          vector-effect="non-scaling-stroke"/>
    <text x="…" y="…" text-anchor="middle" font-weight="600" fill="{ink}">$120</text>
  </svg>
</div>
```

Hard rules:
- `viewBox` **must** equal the image's intrinsic `size` from the JSON. Then every rect coordinate is just the JSON numbers — zero math, zero drift, any screen size.
- `vector-effect="non-scaling-stroke"` keeps strokes exactly 2px at every scale — no hairline fading on small renders, no fat lines on large ones.
- Solid strokes, full opacity, ink `#1D1D1F` on light items / `#FFFFFF` on dark items (the `ink` field in the JSON). Line and any logo in the spot are always the same color.
- No dashed anything. No opacity below 1. No per-spot divs. No % positioning. No object-fit on the img (width:100%/height:auto only, or width and height set together from the same aspect).

### 4. Splitting (owner picks 2 / 3 / 4 / 6 spots)
```js
function splitGrid([x,y,w,h], n){
  const wide = w >= h;
  const [cols, rows] = {2: wide?[2,1]:[1,2], 3: wide?[3,1]:[1,3], 4:[2,2], 6: wide?[3,2]:[2,3]}[n];
  const g = Math.max(3, Math.round(Math.min(w,h) * .035));   // gutter
  const cw = (w - g*(cols-1))/cols, ch = (h - g*(rows-1))/rows;
  const cells = [];
  for (let r=0; r<rows; r++) for (let c=0; c<cols; c++)
    cells.push([x + c*(cw+g), y + r*(ch+g), cw, ch]);
  return cells;
}
function prices(total, n){
  const base = Math.floor(total/n), arr = Array(n).fill(base);
  arr[0] += total - base*n;          // sum is ALWAYS exactly retail
  return arr;
}
```
These two functions are the entire runtime. The same cells drive the posting preview, the checkout spot picker, and (via `ppi`) the physical print size of each purchased spot.

## Acceptance checks
- Resize the browser from 320px to 4K: every box stays glued to the same physical place on the product, strokes stay 2px, nothing fades.
- AirPods Max: the spots sit inside the ear cup, nowhere else.
- MacBook 6-spot: a clean 3×2 grid inside the lid, equal cells, equal gutters.
- Every listed spot shows a real-inch size (from `surface_in` ÷ grid) next to its price.
- Prices per split always sum to the exact retail number.
- View source: exactly one `<svg>` per product image, `viewBox` = intrinsic size, zero dashed strokes, zero opacity attributes.
