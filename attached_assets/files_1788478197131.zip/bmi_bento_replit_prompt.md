# Replit prompt — REPLACE the entire bento section with this rebuilt version

Delete the current bento/feature section (markup, styles, JS) completely and use the source below. The current live version has center-aligned text, dashed strokes, drifting boxes and missing sticker outlines — none of that survives. Do not "merge" old and new; replace.

## Non-negotiable rules encoded in this build
1. **Left-aligned type.** Headlines and body left-aligned inside every tile. Never centered.
2. **Every product image is a sticker.** Every <img> of a product carries class="sticker" (the white die-cut outline via layered drop-shadows). No exceptions.
3. **Solid lines only.** Zero dashed strokes anywhere, at any phase. Spot outlines are solid 2px with vector-effect="non-scaling-stroke" so they never fade or thicken at any screen size.
4. **Precision placement.** Every spot rectangle comes from catalog_surfaces.json (the scanned surfaces): suitcase [13,86,160,225] in a 187×324 viewBox, MacBook [18,18,232,154] in 268×207, cooler [54,55,117,65], duffel [30,52,162,119], backpack [29,44,91,140], AirPods ear cup [12,71,42,50] in 68×149 split into three $183 rows. SVG viewBox always equals the image's intrinsic size; the JSON numbers are the coordinates. No percent-positioned divs, ever.
5. **One colour logic.** The mark is the transparent #lidmark symbol via currentColor: ink #1D1D1F on light items, white on dark items (duffel, backpack), and the spot outlines inherit the same colour.
6. **Copy is locked.** Headlines and subheadlines ship exactly as written here.

## The six tiles
1. Your logo, actually on something — the carry-on with its scanned surface drawing on, the mark stamping in, then a minimal line-drawn doorway and floor draw and the case rolls out of it.
2. Refunded automatically, never held — 1→60 counter over a 60-tick ruler, three receipts flip from charged to refunded at day 60.
3. Real items, not points — rotating catalog (MacBook 6 spots / cooler 2 / weekender 2 / backpack 2), spots split from the scanned surface at runtime, marks stamp in as a funding bar counts to the exact retail number, then it ships off-tile.
4. One photo. On your schedule — check-in photo, flash, verified pill, proof strip that gains a thumbnail per loop. Copy reflects owner-selected cadence (weekly / biweekly / monthly).
5. Priced by surface — the ear cup's three real spots light up ($183 + $183 + $183) while the sum counts to $549 exactly.
6. Pick the term — 6/12/18 proportional bars, selection settles on 12, "First spot sold" → "12 months, locked."

## Acceptance checks
- No dashed strokes and no centered tile text anywhere in the rendered DOM.
- Every product <img> has the sticker outline.
- Resize 320px→4K: spot boxes stay glued to the same place on each product, strokes stay 2px.
- The AirPods spots sit inside the ear cup only. The MacBook shows a clean 3×2 grid inside the lid.
- Funding bar ends exactly on $1,599 / $350 / $495 / $850; the price tile sum ends exactly on $549.
- prefers-reduced-motion shows finished states, no motion.

## THE COPY IS LOCKED — replace every headline and subheadline with EXACTLY these
Tile 1 · "Your logo, actually on something." / "Sticker, patch, embroidery, or engraving. Applied to a real item, carried in public for the whole term."
Tile 2 · "Not funded? Refunded." / "Every spot is charged at checkout. Not fully funded by day 60, every buyer is refunded automatically."
Tile 3 · "Real items, not points." / "When the last spot sells, BrandMyItem buys the item new at retail and ships it straight to the owner."
Tile 4 · "Proof, on a schedule." / "One photo each cycle, weekly, biweekly, or monthly, showing the item and its placements in use."
Tile 5 · "Priced by surface." / (no subheadline; the math row and the ear cup carry it)
Tile 6 · "Pick the term." / "The owner chooses 6, 12, or 18 months when posting. Locked from the moment it's live."
No other headline or subheadline text is permitted in this section. Do not append clarifiers, do not restate mechanics inside tiles, do not center anything.

## FULL SOURCE
```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>BrandMyItem — What brands get</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
  :root{--ink:#1D1D1F;--soft:#6E6E73;--wash:#F5F5F7;--mist:#D2D2D7;--r:30px;--gap:14px;--ease:cubic-bezier(.2,.7,.2,1)}
  *{box-sizing:border-box}
  body{margin:0;background:#fff;font-family:Inter,system-ui,sans-serif;color:var(--ink);padding:80px 24px;-webkit-font-smoothing:antialiased}
  .wrap{max-width:1120px;margin:0 auto}
  .head{max-width:640px;margin:0 0 36px}
  .head h2{font-size:48px;font-weight:700;letter-spacing:-.035em;line-height:1.02;margin:0 0 14px}
  .head p{font-size:19px;line-height:1.45;color:var(--soft);margin:0}

  .bento{display:grid;grid-template-columns:repeat(12,1fr);grid-auto-rows:213px;gap:var(--gap)}
  .tile{position:relative;overflow:hidden;background:var(--wash);border-radius:var(--r);padding:34px 36px;
        opacity:0;transform:translateY(18px);transition:opacity .7s var(--ease),transform .7s var(--ease);transition-delay:calc(var(--i)*90ms)}
  .bento.in .tile{opacity:1;transform:none}
  .tile h3{font-size:27px;font-weight:600;letter-spacing:-.025em;line-height:1.12;margin:0 0 8px;max-width:17ch}
  .tile p{font-size:15px;line-height:1.5;color:var(--soft);margin:0;max-width:34ch}
  .hero{grid-column:1/9;grid-row:1/3}.days{grid-column:9/13;grid-row:1/4}.mac{grid-column:1/5;grid-row:3/6}
  .checkin{grid-column:5/9;grid-row:3/5}.term{grid-column:9/13;grid-row:4/6}.price{grid-column:5/9;grid-row:5/6}
  @media(max-width:900px){.hero,.days,.mac,.checkin,.term,.price{grid-column:1/13;grid-row:auto}.bento{grid-auto-rows:auto}.tile{min-height:460px}.price{min-height:250px}}

  /* every product image is a sticker: white die-cut outline, always */
  .sticker{filter:drop-shadow(3px 0 0 #fff) drop-shadow(-3px 0 0 #fff) drop-shadow(0 3px 0 #fff) drop-shadow(0 -3px 0 #fff) drop-shadow(2px 2px 0 #fff) drop-shadow(-2px -2px 0 #fff) drop-shadow(2px -2px 0 #fff) drop-shadow(-2px 2px 0 #fff)}
  img{display:block;user-select:none;-webkit-user-drag:none}
  svg .ln{fill:none;stroke:currentColor;stroke-width:2;vector-effect:non-scaling-stroke}
  .t{transition:opacity .5s var(--ease),transform .6s var(--ease)}

  /* ================= HERO: the suitcase rolls out of the airport ================= */
  .hero .scene{position:absolute;right:0;top:0;width:430px;height:100%;color:var(--ink);pointer-events:none}
  .hero .scene .d{stroke-dasharray:1;stroke-dashoffset:1;transition:stroke-dashoffset 1s var(--ease)}
  .hero.on .scene .d{stroke-dashoffset:0}
  .hero.on .scene .d2{transition-delay:.22s}.hero.on .scene .d3{transition-delay:.44s}
  .hero[data-phase="0"] .scene .d{transition:none}
  .hero .case{position:absolute;right:44px;top:150px;height:262px;aspect-ratio:187/324;z-index:2}
  .hero .case img{height:100%;width:100%}
  .hero .case > svg{position:absolute;inset:0;width:100%;height:100%;overflow:visible;color:var(--ink)}
  .hero[data-phase="4"] .case.roll{animation:roll 1.5s cubic-bezier(.2,.8,.2,1) .55s both}
  @keyframes roll{0%{transform:translateX(-186px) rotate(-7deg)}72%{transform:translateX(10px) rotate(-2.5deg)}100%{transform:none}}
  /* spot outline draws, mark stamps */
  .hero .surf{stroke-dasharray:1;stroke-dashoffset:1;transition:stroke-dashoffset .9s var(--ease)}
  .hero[data-phase="1"] .surf,.hero[data-phase="2"] .surf,.hero[data-phase="3"] .surf{stroke-dashoffset:0}
  .hero[data-phase="4"] .surf{stroke-dashoffset:0;opacity:0;transition:opacity .4s}
  .hero .stamp{opacity:0;transform:scale(1.16);transform-origin:50% 50%;transition:opacity .35s var(--ease),transform .55s cubic-bezier(.34,1.4,.64,1)}
  .hero[data-phase="2"] .stamp,.hero[data-phase="3"] .stamp,.hero[data-phase="4"] .stamp{opacity:1;transform:none}

  /* ================= DAYS ================= */
  .days .num{position:absolute;left:36px;top:238px;font-size:118px;font-weight:700;letter-spacing:-.06em;line-height:.9}
  .days .num small{font-size:15px;font-weight:600;letter-spacing:0;margin-left:8px;color:var(--soft)}
  .days .ruler{position:absolute;left:36px;right:36px;top:372px;display:grid;grid-template-columns:repeat(60,1fr);gap:2px;height:14px;align-items:end}
  .days .ruler i{display:block;height:6px;background:var(--mist);border-radius:1px;transition:background .2s,height .2s}
  .days .ruler i.on{background:var(--ink)}.days .ruler i:nth-child(10n){height:14px}
  .days .rows{position:absolute;left:36px;right:36px;top:406px;display:flex;flex-direction:column;gap:6px}
  .days .row{display:flex;align-items:center;justify-content:space-between;font-size:12.5px;padding:9px 12px;background:#fff;border:1px solid var(--mist);border-radius:10px;
             opacity:0;transform:translateX(22px);transition:opacity .45s var(--ease),transform .6s var(--ease),border-color .4s}
  .days .row b{font-weight:600}
  .days .row .st{display:inline-flex;align-items:center;gap:6px;color:var(--soft)}
  .days .row .st svg{width:12px;height:12px;display:none}
  .days[data-phase="1"] .row,.days[data-phase="2"] .row,.days[data-phase="3"] .row{opacity:1;transform:none}
  .days[data-phase="1"] .row:nth-child(2){transition-delay:.18s}.days[data-phase="1"] .row:nth-child(3){transition-delay:.36s}
  .days[data-phase="3"] .row{border-color:var(--ink)}
  .days[data-phase="3"] .row .st{color:var(--ink);font-weight:600}
  .days[data-phase="3"] .row .st svg{display:block}
  .days .row .st .w2{display:none}.days[data-phase="3"] .row .st .w1{display:none}.days[data-phase="3"] .row .st .w2{display:inline}
  .days[data-phase="4"] .row{opacity:0;transform:translateX(-22px)}
  .days .note{position:absolute;left:36px;right:36px;bottom:26px;font-size:12px;color:var(--soft);transition:color .3s}
  .days[data-phase="3"] .note{color:var(--ink);font-weight:600}

  /* ================= MAC: rotating catalog on scanned surfaces ================= */
  .mac .itemline{display:flex;justify-content:space-between;align-items:baseline;font-size:13px;margin-top:6px}
  .mac .itemline b{font-weight:600}.mac .itemline span{color:var(--soft);font-size:12px}
  .mac .stage{position:absolute;left:36px;right:36px;bottom:64px;height:300px;display:flex;align-items:flex-end;justify-content:center;
              transition:transform .9s cubic-bezier(.6,0,.4,1),opacity .6s,filter .9s}
  .mac[data-phase="4"] .stage{transform:translateX(115%);opacity:0;filter:blur(6px)}
  .mac[data-phase="0"] .stage{transition:none}
  .mac .stage .art{position:relative;height:100%}
  .mac .stage img{height:100%;width:auto}
  .mac .stage .art > svg{position:absolute;inset:0;width:100%;height:100%;overflow:visible}
  .mac .cell{opacity:0;transform:translateY(4px);transition:opacity .35s var(--ease),transform .45s var(--ease)}
  .mac[data-phase="1"] .cell,.mac[data-phase="2"] .cell,.mac[data-phase="3"] .cell{opacity:1;transform:none}
  .mac .stampg{opacity:0;transform:scale(1.15);transition:opacity .3s var(--ease),transform .5s cubic-bezier(.34,1.4,.64,1)}
  .mac .stampg.on{opacity:1;transform:none}
  .mac .fund{position:absolute;left:36px;right:36px;bottom:26px;font-size:12px;font-weight:600;display:flex;align-items:center;gap:10px;opacity:0;transition:opacity .5s var(--ease)}
  .mac[data-phase="2"] .fund,.mac[data-phase="3"] .fund{opacity:1}
  .mac .bar{flex:1;height:4px;border-radius:2px;background:var(--mist);overflow:hidden}
  .mac .bar i{display:block;height:100%;background:var(--ink);width:0}
  .mac .done{position:absolute;left:50%;top:56%;z-index:5;transform:translate(-50%,8px);background:var(--ink);color:#fff;font-size:12px;font-weight:600;padding:8px 12px;border-radius:999px;display:inline-flex;gap:7px;align-items:center;white-space:nowrap;
             opacity:0;transition:opacity .4s var(--ease),transform .5s var(--ease)}
  .mac .done svg{width:12px;height:12px}
  .mac[data-phase="3"] .done,.mac[data-phase="4"] .done{opacity:1;transform:translate(-50%,0)}
  .mac[data-phase="4"] .done .a{display:none}.mac .done .b{display:none}.mac[data-phase="4"] .done .b{display:inline}

  /* ================= CHECK-IN ================= */
  .checkin .proof{display:flex;gap:8px;margin-top:14px}
  .checkin .proof figure{margin:0;width:64px}
  .checkin .proof img,.checkin .proof span{display:block;width:64px;height:48px;border-radius:10px;object-fit:cover;border:1px solid var(--ink)}
  .checkin .proof span{background:#fff;transition:background .4s}
  .checkin .proof figcaption{font-size:11px;color:var(--soft);margin-top:4px;text-align:center}
  .checkin .proof .next.filled span{background-image:var(--newproof);background-size:cover}
  .checkin .shot{position:absolute;left:-28px;bottom:-92px;height:238px}
  .checkin .shot img{height:100%}
  .checkin .flash{position:absolute;inset:0;background:#fff;opacity:0;transition:opacity .12s}
  .checkin[data-phase="2"] .flash{opacity:.85}
  .checkin .due{position:absolute;right:24px;bottom:44px;font-size:12px;font-weight:600;background:#fff;border:1px solid var(--ink);border-radius:999px;padding:7px 12px;opacity:0;transform:translateY(-6px);transition:opacity .4s,transform .5s var(--ease)}
  .checkin[data-phase="1"] .due{opacity:1;transform:none}
  .checkin .pill{position:absolute;right:24px;bottom:44px;display:flex;align-items:center;gap:8px;background:var(--ink);color:#fff;border-radius:999px;padding:7px 12px 7px 8px;font-size:12px;font-weight:600;opacity:0;transform:translateY(-6px) scale(.96);transition:opacity .4s,transform .5s cubic-bezier(.34,1.4,.64,1)}
  .checkin .pill .ck{width:18px;height:18px;border-radius:50%;background:#fff;display:grid;place-items:center}.checkin .pill .ck svg{width:10px;height:10px}
  .checkin[data-phase="3"] .pill,.checkin[data-phase="4"] .pill{opacity:1;transform:none}

  /* ================= PRICE: the scanned ear cup, three real spots ================= */
  .price h3{font-size:22px}
  .price .math{display:flex;align-items:center;gap:6px;font-size:13px;font-weight:600;margin:10px 0 0;flex-wrap:wrap}
  .price .math span{padding:4px 9px;border:1px solid var(--ink);border-radius:8px;opacity:.25;transition:opacity .3s}
  .price .math span.on{opacity:1}
  .price .math em{font-style:normal;color:var(--soft)}
  .price .sum{position:absolute;left:36px;bottom:22px;display:flex;align-items:baseline;gap:8px}
  .price .sum b{font-size:32px;font-weight:700;letter-spacing:-.05em;line-height:1}
  .price .sum small{font-size:11px;color:var(--soft);opacity:0;transition:opacity .4s}
  .price[data-phase="4"] .sum small{opacity:1}
  .price .art{position:absolute;right:30px;top:50%;transform:translateY(-50%);height:168px;aspect-ratio:68/149;color:var(--ink)}
  .price .art img{height:100%;width:100%}
  .price .art > svg{position:absolute;inset:0;width:100%;height:100%;overflow:visible}
  .price .ps{opacity:0;transition:opacity .3s var(--ease)}
  .price .ps.on{opacity:1}
  .price .lbl{font-family:Inter,sans-serif;font-size:7px;font-weight:600;fill:var(--ink);opacity:0;transition:opacity .3s}
  .price .lbl.on{opacity:1}

  /* ================= TERM ================= */
  .term .suit{position:absolute;right:26px;top:48px;height:142px}
  .term .opts{position:absolute;left:36px;right:36px;bottom:96px;display:flex;flex-direction:column;gap:9px}
  .term .opt{display:grid;grid-template-columns:58px 1fr;align-items:center;gap:12px}
  .term .opt .n{font-size:38px;font-weight:700;letter-spacing:-.05em;line-height:1;color:var(--mist);transition:color .5s var(--ease)}
  .term .opt.on .n{color:var(--ink)}
  .term .bar{height:6px;border-radius:3px;background:var(--mist);position:relative;overflow:hidden}
  .term .bar i{position:absolute;inset:0;background:var(--ink);transform:scaleX(0);transform-origin:left;transition:transform .7s var(--ease)}
  .term .opt.on .bar i{transform:scaleX(1)}
  .term .opt .m{font-size:11px;color:var(--soft);margin-top:4px}
  .term .status{position:absolute;left:36px;bottom:28px;font-size:12px;font-weight:600;display:inline-flex;gap:7px;align-items:center;background:#fff;border:1px solid var(--ink);border-radius:999px;padding:7px 11px;opacity:0;transform:translateY(6px);transition:all .45s var(--ease)}
  .term .status svg{width:12px;height:12px}
  .term[data-phase="2"] .status,.term[data-phase="3"] .status{opacity:1;transform:none}
  .term .status .s1{display:inline}.term .status .s2{display:none}
  .term[data-phase="3"] .status{background:var(--ink);color:#fff;border-color:var(--ink)}
  .term[data-phase="3"] .status .s1{display:none}.term[data-phase="3"] .status .s2{display:inline}

  @media (prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}.tile{opacity:1;transform:none}}
</style>
</head>
<body>
<svg width="0" height="0" style="position:absolute"><symbol id="lidmark" viewBox="0 0 64 64"><path fill="currentColor" fill-rule="evenodd" d="M14 9h36a6 6 0 0 1 6 6v29a6 6 0 0 1-6 6H14a6 6 0 0 1-6-6V15a6 6 0 0 1 6-6zM15 13h12a3 3 0 0 1 3 3v8.5a3 3 0 0 1-3 3H15a3 3 0 0 1-3-3V16a3 3 0 0 1 3-3zm22 0h12a3 3 0 0 1 3 3v8.5a3 3 0 0 1-3 3H37a3 3 0 0 1-3-3V16a3 3 0 0 1 3-3zM15 31.5h12a3 3 0 0 1 3 3V43a3 3 0 0 1-3 3H15a3 3 0 0 1-3-3v-8.5a3 3 0 0 1 3-3zm22 0h12a3 3 0 0 1 3 3V43a3 3 0 0 1-3 3H37a3 3 0 0 1-3-3v-8.5a3 3 0 0 1 3-3z"/><path fill="currentColor" d="M5 53h54a2 2 0 0 1 0 4H5a2 2 0 0 1 0-4z"/></symbol></svg>

<div class="wrap">
  <div class="head">
    <h2>What brands get.</h2>
    <p>Real placement on real items, with the money and the proof handled for you.</p>
  </div>

  <div class="bento" id="bento">

    <!-- HERO -->
    <div class="tile hero" data-phase="0" data-loop="11000" style="--i:0">
      <svg class="scene" viewBox="0 0 430 440" preserveAspectRatio="xMaxYMax slice">
        <line class="ln d d1" pathLength="1" x1="-40" y1="412" x2="430" y2="412"/>
        <rect class="ln d d2" pathLength="1" x="42" y="120" width="160" height="292" rx="6"/>
        <line class="ln d d2" pathLength="1" x1="122" y1="120" x2="122" y2="412"/>
        <line class="ln d d3" pathLength="1" x1="62" y1="152" x2="62" y2="382"/>
        <line class="ln d d3" pathLength="1" x1="182" y1="152" x2="182" y2="382"/>
      </svg>
      <h3>Your logo, actually on something.</h3>
      <p>Sticker, patch, embroidery, or engraving. Applied to a real item, carried in public for the whole term.</p>
      <div class="case" id="heroCase">
        <img class="sticker" src="{{SUITCASE}}" alt="">
        <svg viewBox="0 0 187 324">
          <!-- the scanned surface: catalog_surfaces.json → suitcase [13,86,160,225] -->
          <rect class="ln surf" pathLength="1" x="13" y="86" width="160" height="225" rx="16"/>
          <g class="stamp"><svg x="45" y="140" width="96" height="96" viewBox="0 0 64 64"><use href="#lidmark"/></svg></g>
        </svg>
      </div>
    </div>

    <!-- DAYS -->
    <div class="tile days" data-phase="0" data-loop="12000" style="--i:1">
      <h3>Not funded? Refunded.</h3>
      <p>Every spot is charged at checkout. Not fully funded by day 60, every buyer is refunded automatically.</p>
      <div class="num"><span id="dayNum">1</span><small>days</small></div>
      <div class="ruler" id="ruler"></div>
      <div class="rows">
        <div class="row"><b>Spot 1</b><span class="st"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/></svg><span class="w1">$233 charged</span><span class="w2">$233 refunded</span></span></div>
        <div class="row"><b>Spot 2</b><span class="st"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/></svg><span class="w1">$233 charged</span><span class="w2">$233 refunded</span></span></div>
        <div class="row"><b>Spot 3</b><span class="st"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/></svg><span class="w1">$233 charged</span><span class="w2">$233 refunded</span></span></div>
      </div>
      <div class="note" id="dayNote">3 of 5 spots claimed</div>
    </div>

    <!-- MAC -->
    <div class="tile mac" data-phase="0" data-loop="11000" style="--i:2">
      <h3>Real items, not points.</h3>
      <p>When the last spot sells, BrandMyItem buys the item new at retail and ships it straight to the owner.</p>
      <div class="itemline"><b id="itemName">MacBook Pro 14"</b><span id="itemMeta">$1,599 retail · 6 spots</span></div>
      <div class="done"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg><span class="a">Fully funded. Bought at retail.</span><span class="b">Shipped to the owner</span></div>
      <div class="stage"><div class="art" id="macArt"><img id="itemImg" src="{{MACBOOK}}" alt=""><svg id="itemSvg"></svg></div></div>
      <div class="fund"><span id="fundPct">0%</span><div class="bar"><i id="fundBar"></i></div><span id="fundAmt">$0 of $1,599</span></div>
    </div>

    <!-- CHECK-IN -->
    <div class="tile checkin" data-phase="0" data-loop="7000" style="--i:3">
      <h3>Proof, on a schedule.</h3>
      <p>One photo each cycle, weekly, biweekly, or monthly, showing the item and its placements in use.</p>
      <div class="proof" id="proof">
        <figure><img src="{{PROOF0}}" alt=""><figcaption>Jun</figcaption></figure>
        <figure><img src="{{PROOF1}}" alt=""><figcaption>Jul</figcaption></figure>
        <figure><img src="{{PROOF2}}" alt=""><figcaption>Aug</figcaption></figure>
        <figure class="next"><span></span><figcaption id="nextCap">Sep</figcaption></figure>
      </div>
      <div class="shot"><img class="sticker" src="{{CHECKIN}}" alt=""><div class="flash"></div></div>
      <div class="due">Photo due · <span id="dueMonth">September</span></div>
      <div class="pill"><span class="ck"><svg viewBox="0 0 12 12" fill="none" stroke="#1D1D1F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 6.5l2.6 2.5L10 3.5"/></svg></span><span id="okMonth">September</span> verified</div>
    </div>

    <!-- PRICE -->
    <div class="tile price" data-phase="0" data-loop="9000" style="--i:5">
      <h3>Priced by surface.</h3>
      <div class="math"><span data-k="0">$183</span><em>+</em><span data-k="1">$183</span><em>+</em><span data-k="2">$183</span><em>=</em></div>
      <div class="sum"><b>$<span id="sumNum">0</span></b><small>= retail, exactly</small></div>
      <div class="art">
        <img class="sticker" src="{{HEADPHONES}}" alt="">
        <svg viewBox="0 0 68 149">
          <!-- the scanned ear cup: catalog_surfaces.json → headphones [12,71,42,50], split 3 -->
          <rect class="ln ps" data-k="0" x="12" y="71"    width="42" height="15.3" rx="4"/>
          <rect class="ln ps" data-k="1" x="12" y="88.3"  width="42" height="15.3" rx="4"/>
          <rect class="ln ps" data-k="2" x="12" y="105.6" width="42" height="15.4" rx="4"/>
          <text class="lbl" data-k="0" x="58" y="81">$183</text>
          <text class="lbl" data-k="1" x="58" y="98">$183</text>
          <text class="lbl" data-k="2" x="58" y="115">$183</text>
        </svg>
      </div>
    </div>

    <!-- TERM -->
    <div class="tile term" data-phase="0" data-loop="9000" style="--i:4">
      <h3>Pick the term.</h3>
      <p style="max-width:19ch">The owner chooses 6, 12, or 18 months when posting. Locked from the moment it's live.</p>
      <img class="suit sticker" src="{{SUIT}}" alt="">
      <div class="opts">
        <div class="opt" data-k="0"><div class="n">6</div><div><div class="bar" style="width:33%"><i></i></div><div class="m">months</div></div></div>
        <div class="opt" data-k="1"><div class="n">12</div><div><div class="bar" style="width:66%"><i></i></div><div class="m">months</div></div></div>
        <div class="opt" data-k="2"><div class="n">18</div><div><div class="bar" style="width:100%"><i></i></div><div class="m">months</div></div></div>
      </div>
      <div class="status"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg><span class="s1">Listing posted</span><span class="s2">12 months, locked</span></div>
    </div>

  </div>
</div>

<script>
(function(){
  const ease = t => 1 - Math.pow(1 - t, 3);
  const clamp = (v,a,b) => Math.min(b, Math.max(a, v));
  const seg = (p,a,b) => clamp((p-a)/(b-a), 0, 1);
  const $ = (r,s) => r.querySelector(s), $$ = (r,s) => [...r.querySelectorAll(s)];

  const grid = document.getElementById('bento');
  const io = 'IntersectionObserver' in window ? new IntersectionObserver(e => { if (e[0].isIntersecting){ grid.classList.add('in'); io.disconnect(); } }, {threshold:.12}) : null;
  io ? io.observe(grid) : grid.classList.add('in');

  function tile(sel, schedule, onFrame){
    const el = $(document, sel), T = +el.dataset.loop, start = performance.now();
    let last = -1;
    (function tick(now){
      const p = ((now - start) % T) / T;
      let ph = 0; for (const [at,k] of schedule) if (p >= at) ph = k;
      if (ph !== last){ el.dataset.phase = ph; last = ph; }
      onFrame && onFrame(p, ph, el);
      requestAnimationFrame(tick);
    })(start);
  }

  // HERO: 1 surface draws → 2 mark stamps → 3 hold → 4 scene draws, case rolls out
  const heroCase = document.getElementById('heroCase');
  tile('.hero', [[0,0],[.06,1],[.26,2],[.46,3],[.58,4],[.94,0]], (p, ph, el) => {
    el.classList.toggle('on', ph === 4);
    if (ph === 4) heroCase.classList.add('roll');
    if (ph === 0) heroCase.classList.remove('roll');
  });

  // DAYS
  const dayNum = $(document,'#dayNum'), dayNote = $(document,'#dayNote'), ruler = $(document,'#ruler');
  ruler.innerHTML = '<i></i>'.repeat(60); const ticks = $$(ruler,'i');
  tile('.days', [[0,0],[.05,1],[.20,2],[.70,3],[.90,4]], (p, ph) => {
    const d = ph >= 2 ? (ph === 2 ? Math.max(1, Math.round(seg(p,.20,.70)*60)) : 60) : 1;
    if (dayNum.textContent != d){ dayNum.textContent = d; ticks.forEach((t,i)=>t.classList.toggle('on', ph>=2 && ph<4 && i<d)); }
    if (ph === 4 || ph === 0) ticks.forEach(t=>t.classList.remove('on'));
    const note = ph === 3 ? 'Not sold out. All 3 refunded automatically' : (ph >= 1 && ph < 4 ? '3 of 5 spots claimed' : '');
    if (dayNote.textContent !== note) dayNote.textContent = note;
  });

  // MAC: precision surfaces from catalog_surfaces.json, split at runtime
  const items = [
    {name:'MacBook Pro 14"',   price:1599, img:'{{MACBOOK}}',  size:[268,207], surf:[18,18,232,154],  n:6, ink:'#1D1D1F'},
    {name:'Hard cooler',       price:350,  img:'{{COOLER}}',   size:[191,154], surf:[54,55,117,65],   n:2, ink:'#1D1D1F'},
    {name:'Weekender',         price:495,  img:'{{DUFFEL}}',   size:[225,180], surf:[30,52,162,119],  n:2, ink:'#FFFFFF'},
    {name:'Commuter backpack', price:850,  img:'{{BACKPACK}}', size:[152,216], surf:[29,44,91,140],   n:2, ink:'#FFFFFF'},
  ];
  function splitGrid([x,y,w,h], n){
    const wide = w >= h;
    const [cols, rows] = {2: wide?[2,1]:[1,2], 3: wide?[3,1]:[1,3], 4:[2,2], 6: wide?[3,2]:[2,3]}[n];
    const g = Math.max(3, Math.round(Math.min(w,h)*.05));
    const cw = (w-g*(cols-1))/cols, ch = (h-g*(rows-1))/rows, cells = [];
    for (let r=0;r<rows;r++) for (let c=0;c<cols;c++) cells.push([x+c*(cw+g), y+r*(ch+g), cw, ch]);
    return cells;
  }
  let it = 0, stamps = [];
  const itemImg=$(document,'#itemImg'), itemSvg=$(document,'#itemSvg'), itemName=$(document,'#itemName'), itemMeta=$(document,'#itemMeta'),
        fundPct=$(document,'#fundPct'), fundBar=$(document,'#fundBar'), fundAmt=$(document,'#fundAmt'), macArt=$(document,'#macArt');
  function loadItem(){
    const d = items[it];
    itemImg.src = d.img; itemImg.className = 'sticker';
    itemName.textContent = d.name; itemMeta.textContent = '$'+d.price.toLocaleString()+' retail · '+d.n+' spots';
    itemSvg.setAttribute('viewBox','0 0 '+d.size[0]+' '+d.size[1]); itemSvg.style.color = d.ink;
    macArt.style.aspectRatio = d.size[0]+'/'+d.size[1];
    const cells = splitGrid(d.surf, d.n), r = Math.max(3, Math.min(cells[0][2],cells[0][3])*.1);
    itemSvg.innerHTML =
      cells.map((c,i)=>`<rect class="ln cell" style="transition-delay:${i*.05}s" x="${c[0]}" y="${c[1]}" width="${c[2]}" height="${c[3]}" rx="${r}"/>`).join('') +
      cells.map(c=>{ const m = Math.min(c[2],c[3])*.6, x=c[0]+(c[2]-m)/2, y=c[1]+(c[3]-m)/2;
        return `<g class="stampg" style="color:${d.ink};transform-origin:${x+m/2}px ${y+m/2}px"><svg x="${x}" y="${y}" width="${m}" height="${m}" viewBox="0 0 64 64"><use href="#lidmark"/></svg></g>`; }).join('');
    stamps = $$(itemSvg,'.stampg');
  }
  loadItem();
  tile('.mac', [[0,0],[.05,1],[.18,2],[.62,3],[.78,4],[.95,0]], (p, ph, el) => {
    if (ph === 0 && !el._swapped && p > .95){ el._swapped = true; it = (it+1)%items.length; loadItem(); }
    if (ph === 1) el._swapped = false;
    const n = stamps.length, price = items[it].price;
    const f = ph === 2 ? ease(seg(p,.18,.62)) : (ph >= 3 && p < .95 ? 1 : 0);
    stamps.forEach((s,i)=>s.classList.toggle('on', f >= (i+1)/n - .001));
    const pct = Math.round(f*100), amt = pct === 100 ? price : Math.round(f*price);
    fundBar.style.width = pct+'%';
    if (fundPct.textContent !== pct+'%'){ fundPct.textContent = pct+'%'; fundAmt.textContent = '$'+amt.toLocaleString()+' of $'+price.toLocaleString(); }
  });

  // CHECK-IN
  const M = ['January','February','March','April','May','June','July','August','September','October','November','December'], Ms = M.map(m=>m.slice(0,3));
  let mi = 8, pi = 0;
  const proofs = ['{{PROOF0}}','{{PROOF1}}','{{PROOF2}}'];
  const proof = $(document,'#proof'), nextFig = $(proof,'.next'), nextCap = $(document,'#nextCap'),
        dueMonth = $(document,'#dueMonth'), okMonth = $(document,'#okMonth');
  tile('.checkin', [[0,0],[.04,1],[.30,2],[.34,3],[.62,4],[.96,0]], (p, ph, el) => {
    if (ph === 4 && !el._logged){ el._logged = true; nextFig.style.setProperty('--newproof', `url(${proofs[pi]})`); nextFig.classList.add('filled'); }
    if (ph === 0 && el._logged){
      el._logged = false;
      const figs = $$(proof,'figure'), fresh = figs[0];
      fresh.querySelector('img').src = proofs[pi]; fresh.querySelector('figcaption').textContent = Ms[mi];
      proof.appendChild(fresh); proof.insertBefore(nextFig, null);
      nextFig.classList.remove('filled'); pi = (pi+1)%3; mi = (mi+1)%12;
      dueMonth.textContent = okMonth.textContent = M[mi]; nextCap.textContent = Ms[mi];
    }
  });

  // PRICE: three real spots on the scanned ear cup
  const ps = $$(document,'.price .ps'), lbls = $$(document,'.price .lbl'), mathc = $$(document,'.price .math span'), sumNum = $(document,'#sumNum');
  const parts = [183,183,183];
  tile('.price', [[0,0],[.06,1],[.28,2],[.50,3],[.72,4],[.94,0]], (p, ph) => {
    let total = 0;
    parts.forEach((v,i)=>{ const on = ph >= i+1 && ph <= 4;
      ps[i].classList.toggle('on', on); lbls[i].classList.toggle('on', on); mathc[i].classList.toggle('on', on);
      const a = [.06,.28,.50][i], f = on ? ease(seg(p, a, a+.16)) : 0; total += Math.round(v*f); });
    if (ph === 0) total = 0;
    sumNum.textContent = total.toLocaleString();
  });

  // TERM
  const opts = $$(document,'.term .opt');
  tile('.term', [[0,0],[.04,1],[.56,2],[.72,3],[.95,0]], (p, ph) => {
    let k = 1;
    if (ph === 1){ const w = seg(p,.04,.56); k = w < .3 ? 0 : (w < .6 ? 1 : (w < .82 ? 2 : 1)); }
    opts.forEach((o,i)=>o.classList.toggle('on', ph >= 1 && i === k));
  });
})();
</script>
</body>
</html>

```
