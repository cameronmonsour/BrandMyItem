"""
BrandMyItem surface scanner.
Run once per catalog asset (transparent-PNG product cutout).
Outputs catalog_surfaces.json: the traced ad surface per product, in the
image's own pixel space. The site splits that surface at runtime.

Usage: python3 scan_surfaces.py assets/*.png
Deps:  pip install pillow scipy numpy
"""
import sys, os, json
import numpy as np
from PIL import Image
from scipy import ndimage

def largest_rect(mask):
    h, w = mask.shape
    heights = np.zeros(w, dtype=int); best = (0,0,0,0); best_area = 0
    for y in range(h):
        heights = np.where(mask[y], heights+1, 0)
        stack = []
        for x in range(w+1):
            cur = heights[x] if x < w else 0
            start = x
            while stack and stack[-1][1] > cur:
                sx, sh = stack.pop()
                if sh*(x-sx) > best_area: best_area = sh*(x-sx); best = (sx, y-sh+1, x-sx, sh)
                start = sx
            stack.append((start, cur))
    return best

def scan(path, margin_frac=0.045, alpha_thresh=8):
    im = Image.open(path).convert("RGBA")
    a = np.array(im)[:, :, 3] >= alpha_thresh          # soft-alpha cutouts included
    mask = ndimage.binary_fill_holes(a)                # keyed-out interiors included
    margin = max(2, int(min(im.size) * margin_frac))   # keep off the silhouette edge
    x, y, w, h = largest_rect(ndimage.distance_transform_edt(mask) >= margin)
    return {"img": os.path.basename(path), "size": [im.width, im.height],
            "surface": [int(x), int(y), int(w), int(h)]}

if __name__ == "__main__":
    out = {}
    for p in sys.argv[1:]:
        key = os.path.splitext(os.path.basename(p))[0]
        out[key] = scan(p)
        print(key, out[key]["surface"])
    json.dump(out, open("catalog_surfaces.json", "w"), indent=1)
